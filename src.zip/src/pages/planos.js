import Title from './../components/Title/index';

 
function Planos(){
    return (
        <div>
            <Title
                title={"Planos"}
                text={"Veja alguns dos planos que a Piratoflix te oferece:"} />
            {/* <Card /> */}
            <div class="row row-cols-1 row-cols-md-3 mb-3 text-center">
      <div class="col">
      <div class="card mb-4 rounded-3 shadow-sm border-primary">
      <h4 class="my-0 fw-normal" _msttexthash="94315" _msthash="29">Seu plano é esse</h4>
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-header py-3">
            <h4 class="my-0 fw-normal" _msttexthash="60905" _msthash="15">Pobre</h4>
          </div>
          <div class="card-body">
            <h1 class="card-title pricing-card-title" _msttexthash="79339" _msthash="16">$0<small class="text-body-secondary fw-light" _istranslated="1">/mês</small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li _msttexthash="476970" _msthash="17">5 usuários incluídos</li>
              <li _msttexthash="374335" _msthash="18">2 GB de armazenamento</li>
              <li _msttexthash="309010" _msthash="19">Suporte por e-mail</li>
            </ul>
            <button type="button" class="w-100 btn btn-lg btn-outline-primary" _msttexthash="606255" _msthash="21">Inscreva-se gratuitamente</button>
          </div>
        </div>
      </div>
      </div>
      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-header py-3">
            <h4 class="my-0 fw-normal" _msttexthash="47567" _msthash="22">Classe Média</h4>
          </div>
          <div class="card-body">
            <h1 class="card-title pricing-card-title" _msttexthash="92209" _msthash="23">$15<small class="text-body-secondary fw-light" _istranslated="1">/mês</small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li _msttexthash="477061" _msthash="24">20 usuários incluídos</li>
              <li _msttexthash="401752" _msthash="25">10 GB de armazenamento</li>
              <li _msttexthash="769808" _msthash="26">Suporte prioritário por e-mail</li>
              <li _msttexthash="488280" _msthash="27">Acesso à Central de Ajuda</li>
            </ul>
            <button type="button" class="w-100 btn btn-lg btn-primary" _msttexthash="110955" _msthash="28">Começar</button>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card mb-4 rounded-3 shadow-sm">
          <div class="card-header py-3">
            <h4 class="my-0 fw-normal" _msttexthash="94315" _msthash="29">Burgues</h4>
          </div>
          <div class="card-body">
          <h1 class="card-title pricing-card-title" _msttexthash="92209" _msthash="23">$25<small class="text-body-secondary fw-light" _istranslated="1">/mês</small></h1>
            <ul class="list-unstyled mt-3 mb-4">
              <li _msttexthash="477152" _msthash="31">30 usuários incluídos</li>
              <li _msttexthash="402272" _msthash="32">15 GB de armazenamento</li>
              <li _msttexthash="634140" _msthash="33">Suporte por telefone e e-mail</li>
              <li _msttexthash="488280" _msthash="34">Acesso à Central de Ajuda</li>
            </ul>
            <button type="button" class="w-100 btn btn-lg btn-primary" _msttexthash="499213" _msthash="35">Começar</button>
          </div>
        </div>
      </div>
    </div>         
        </div>
    )   
}
 
export default Planos;